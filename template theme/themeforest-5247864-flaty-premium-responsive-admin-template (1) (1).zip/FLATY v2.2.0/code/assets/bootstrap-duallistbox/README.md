# Bootstrap Dual Listbox

##### Bootstrap Dual Listbox is a responsive dual listbox widget optimized for Twitter Bootstrap. Works on all modern browsers and on touch devices.

- [Website](http://www.virtuosoft.eu/code/bootstrap-duallistbox/)

Please report issues and feel free to make feature suggestions as well.

## License

Apache License, Version 2.0

[![githalytics.com alpha](https://cruel-carlota.pagodabox.com/73ffb6b38e5099909d7b13c577d7e5c8 "githalytics.com")](http://githalytics.com/istvan-ujjmeszaros/bootstrap-duallistbox)
